package com.crimson.app.crimson.model;


import com.crimson.app.crimson.common.Roles;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.List;
import java.util.Set;


@Entity
@Table(name = "T_USERS")
@Getter
@Setter
public class User {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long userId;

    @Column(name = "last_name")
    private String lastName;
    @Column(name = "first_name")
    private String firstName;
    @Column(name = "middle_name")
    private String middleName;

    private String address;

    private String status;

    @Column(name = "email_address")
    private String email;

    @Column(name = "password_hash")
    private String passWordHash;

    @Column(name = "phone_number")
    private String phoneNumber;

    @Enumerated(EnumType.STRING)
    private Roles role;

    @CreationTimestamp
    private LocalDateTime timestamp;

    private String profilePicture;

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "T_AUTHORITY", joinColumns = @JoinColumn(name = "user_id"))
    @Column(name = "authority_name")
    private Set<String> authorities;

}
