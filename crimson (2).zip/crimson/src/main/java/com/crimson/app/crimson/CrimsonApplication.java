package com.crimson.app.crimson;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CrimsonApplication {

	public static void main(String[] args) {
		SpringApplication.run(CrimsonApplication.class, args);
	}

}
