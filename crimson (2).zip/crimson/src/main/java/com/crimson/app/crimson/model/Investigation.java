package com.crimson.app.crimson.model;

import com.crimson.app.crimson.common.InvestigationStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "T_INVESTIGATION")
@Getter
@Setter
public class Investigation {

    @Id
    @GeneratedValue(strategy =  GenerationType.IDENTITY)
    private Long investigationId;

    @ManyToOne
    @JoinColumn(name = "complaint_id", nullable = false)
    private Complaint complaint;

    @ManyToOne
    @JoinColumn(name = "investigator_id", nullable = false)
    private User investigator;

    private String findings;

    @Enumerated(EnumType.STRING)
    private InvestigationStatus investigationStatus = InvestigationStatus.PENDING_REVIEW;

    @ElementCollection
    private List<String> investigationNotes = new ArrayList<>();

    @CreationTimestamp
    private LocalDateTime startedAt;

    @UpdateTimestamp
    private LocalDateTime updateAt;


}
