package com.crimson.app.crimson.service.imp;


import com.crimson.app.crimson.dto.ComplaintCategoryDto;


import java.util.List;

public interface ComplaintCategoryService {

    List<ComplaintCategoryDto> findALl();
}
