package com.crimson.app.crimson.model;


import com.crimson.app.crimson.common.ComplaintCategory;
import com.crimson.app.crimson.common.ComplaintStatus;
import com.crimson.app.crimson.common.InvestigationStatus;
import jakarta.persistence.*;
import lombok.Getter;
import lombok.Setter;
import org.hibernate.annotations.CreationTimestamp;
import org.hibernate.annotations.UpdateTimestamp;

import java.sql.Timestamp;
import java.time.LocalDateTime;

@Entity
@Table(name = "T_COMPLAINT")
@Getter
@Setter
public class Complaint {

    @Id
    @GeneratedValue(strategy =  GenerationType.SEQUENCE, generator = "complaint_seq")
    @SequenceGenerator(name = "complaint_seq",sequenceName = "complaint_seq",allocationSize = 1)
    private Long complaintId;

    @ManyToOne
    @JoinColumn(name = "userId")
    private User user;

    @ManyToOne
    @JoinColumn(name = "investigator_id")
    private User investigator;

    @ManyToOne
    @JoinColumn(name = "complaintCategoryId")
    private MdlComplaintCategory complaintCategory;


    private String description;
    private String cancellationReason;

    @Enumerated(EnumType.STRING)
    private ComplaintCategory category;

    @Enumerated(EnumType.STRING)
    private ComplaintStatus status = ComplaintStatus.SUBMITTED;

    @Enumerated(EnumType.STRING)
    private InvestigationStatus investigationStatus = InvestigationStatus.PENDING_REVIEW;

    private LocalDateTime filedAT;

    private LocalDateTime updatedAT;

}
