package com.crimson.app.crimson.common;

public enum Roles {
    COMPLAINANT,
    INVESTIGATOR,
    ADMIN
}
