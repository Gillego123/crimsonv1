package com.crimson.app.crimson.common;

public enum InvestigationStatus {

    PENDING_REVIEW,
    IN_PROGRESS,
    REQUESTING_EVIDENCE,
    ESCALATED,
    AWAITING_RSPONSE,
    COMPLETED,
    CLOSED
}
