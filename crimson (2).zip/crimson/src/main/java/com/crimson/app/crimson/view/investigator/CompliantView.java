package com.crimson.app.crimson.view.investigator;

public class CompliantView {
}
